package com.doodleapp.animation;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.doodleapp.animation.xfl.Matrix;

public class Shape implements DrawableRecurse {

	@Override
	public void drawRecurse(SpriteBatch batch, int index, float x, float y,
			float width, float height, Matrix matrix) {
		// TODO Auto-generated method stub

	}

}
