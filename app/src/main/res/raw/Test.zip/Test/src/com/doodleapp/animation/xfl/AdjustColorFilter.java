package com.doodleapp.animation.xfl;

import com.badlogic.gdx.utils.XmlReader.Element;

public class AdjustColorFilter {

	public AdjustColorFilter(Element tmp) {
		// TODO Auto-generated constructor stub
	}

}
