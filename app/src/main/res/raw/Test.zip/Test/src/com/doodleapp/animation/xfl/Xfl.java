package com.doodleapp.animation.xfl;

public class Xfl {
	public DOMTimeline timelines;
}

